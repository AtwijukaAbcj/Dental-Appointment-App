<form method="post" name="frm" action="userregister.php" enctype="multipart/form-data">
    <input type="text" name="username" value="username">
    <input type="text" name="email" value="email">
    <input type="text" name="password" value="password">
    <input type="text" name="reg_id" value="reg_id">
    <input type="text" name="platform" value="platform">
    <input type="file" name="file">
    <input type="submit" name="submit" value="register">
</form>