-- phpMyAdmin SQL Dump
-- version 4.0.10.18
-- https://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Apr 18, 2018 at 10:41 AM
-- Server version: 10.1.31-MariaDB-cll-lve
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `herbpkyx_dentist`
--

-- --------------------------------------------------------

--
-- Table structure for table `clinic_adminlogin`
--

CREATE TABLE IF NOT EXISTS `clinic_adminlogin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `icon` varchar(250) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `clinic_adminlogin`
--

INSERT INTO `clinic_adminlogin` (`id`, `username`, `password`, `fullname`, `email`, `phone`, `icon`, `is_active`) VALUES
(1, 'admin', '123', 'administrator', 'admin@gmail.com', '9601604082', 'admin_1470741942.jpeg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `clinic_city`
--

CREATE TABLE IF NOT EXISTS `clinic_city` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `clinic_city`
--

INSERT INTO `clinic_city` (`id`, `name`, `created_at`) VALUES
(4, 'Kampala, Uganda', 1523963340),
(5, 'Jinja, Uganda', 1523963349),
(6, 'Mbale, Uganda', 1523963360),
(7, 'Gulu, Uganda', 1523963370),
(8, 'Lira, Uganda', 1523963385),
(9, 'Fort Portal, Uganda', 1523963397),
(10, 'Kawempe, Uganda', 1523963405),
(11, 'Bwaise, Uganda', 1523963413),
(12, 'Makerere, Uganda', 1523963423),
(13, 'Mulago, Uganda', 1523963439);

-- --------------------------------------------------------

--
-- Table structure for table `clinic_notification`
--

CREATE TABLE IF NOT EXISTS `clinic_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `apikey` varchar(300) NOT NULL,
  `ioskey` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `clinic_profile`
--

CREATE TABLE IF NOT EXISTS `clinic_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mcat_id` int(11) NOT NULL,
  `spcat_id` int(11) NOT NULL,
  `icon` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(120) NOT NULL,
  `hours` varchar(50) NOT NULL,
  `lat` varchar(30) NOT NULL,
  `lon` varchar(30) NOT NULL,
  `about` text NOT NULL,
  `services` varchar(500) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(50) NOT NULL,
  `goole_plus` varchar(200) NOT NULL,
  `helthcare` text NOT NULL,
  `facebook` varchar(200) NOT NULL,
  `twiter` varchar(200) NOT NULL,
  `linkedin` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `clinic_profile`
--

INSERT INTO `clinic_profile` (`id`, `mcat_id`, `spcat_id`, `icon`, `name`, `phone`, `email`, `hours`, `lat`, `lon`, `about`, `services`, `address`, `city`, `goole_plus`, `helthcare`, `facebook`, `twiter`, `linkedin`) VALUES
(1, 1, 12, 'profile_1523963681.jpg', 'Namata Sheila', '+256702112233', 'snamata@gmail.com', '6:00AM to 6:00PM', '0.3450215263803474', '32.57762735075687', 'Check my clinic for more details', 'Dentistry', 'Plot 2, Mulago Road', '4', '', 'All the best you can have!', '', 'http://twitter.com/SNamata', ''),
(2, 1, 12, 'profile_1523964996.jpg', 'BRANDON PRAISE', '0+256702911911', 'deejahn@gmail.com', '7:00AM to 9:00PM', '0.352943170368103', '32.565995585241694', 'Dentistry', 'Dentistry', 'Plot 7, Jinja Town', '10', '', 'Dentistry', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `clinic_reviewratting`
--

CREATE TABLE IF NOT EXISTS `clinic_reviewratting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `review_text` text NOT NULL,
  `ratting` varchar(10) NOT NULL,
  `created_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `clinic_sendnotification`
--

CREATE TABLE IF NOT EXISTS `clinic_sendnotification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `clinic_specialist`
--

CREATE TABLE IF NOT EXISTS `clinic_specialist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sp_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `icon` varchar(300) NOT NULL,
  `created_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `clinic_specialist`
--

INSERT INTO `clinic_specialist` (`id`, `sp_id`, `name`, `icon`, `created_at`) VALUES
(12, 1, 'Dentist', 'specialities_1523963481.png', 146798987);

-- --------------------------------------------------------

--
-- Table structure for table `clinic_tokendata`
--

CREATE TABLE IF NOT EXISTS `clinic_tokendata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` text NOT NULL,
  `device_type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `clinic_tokendata`
--

INSERT INTO `clinic_tokendata` (`id`, `device_id`, `device_type`) VALUES
(1, 'f2-DvSVQ4uk:APA91bFMiZdKS7rBkJg4teod34WX0iY8-BtNsCyOnb8loX11oBlNk_bO31L9EIblUv9ZIFCNBPJdFFeaRXXY5hTIRtZ3Esb0hOiB2TbzG6MmZZuXla3mdn8Vp4W75LzTNtECre4UMxlc', 'android'),
(2, 'cdZkk-rd7Xw:APA91bEiP0ClepgOddfl1nhLM_07mYQYphgPvMQe9--zE5yj4u614LzzeHqB2vkmGRqp1mD73X4XV7sUncQ4njOogN4TZiPyrHTIoI75KQwZaxObXVF9s87vPZ_z8Jy7vGc3ndNviBWu', 'android'),
(3, 'dN-Id8M6wvU:APA91bHB3Xpib5sCVvy-ZLCUpklUamCckx4m1HUmH2fdu7sb4No6Z-umFqo2eaU4bJwLf7TGLSrPz4wB3Q5r5pDw_wldBQLfTlPoL9JoSWmlKLGXGXr2UlxyI2V81jQxIPqDbqrV2hKz', 'android');

-- --------------------------------------------------------

--
-- Table structure for table `clinic_users`
--

CREATE TABLE IF NOT EXISTS `clinic_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `email` varchar(120) NOT NULL,
  `password` varchar(40) NOT NULL,
  `image` text NOT NULL,
  `created_at` int(11) NOT NULL,
  `reg_type` varchar(100) NOT NULL,
  `reg_id` text NOT NULL,
  `platform` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `clinic_users`
--

INSERT INTO `clinic_users` (`id`, `username`, `email`, `password`, `image`, `created_at`, `reg_type`, `reg_id`, `platform`) VALUES
(1, 's0kie', 'me@herbertmusoke.com', 'cUlpbTRGUVRIY3diNzJiNG0rNHZnZz09', 'mobileuser_1523965309.png', 1523965309, 'appuser', 'f2-DvSVQ4uk:APA91bFMiZdKS7rBkJg4teod34WX0iY8-BtNsCyOnb8loX11oBlNk_bO31L9EIblUv9ZIFCNBPJdFFeaRXXY5hTIRtZ3Esb0hOiB2TbzG6MmZZuXla3mdn8Vp4W75LzTNtECre4UMxlc', 'Android'),
(2, 'gggg', 'hhh@mg.com', 'cUlpbTRGUVRIY3diNzJiNG0rNHZnZz09', 'mobileuser_1523976270.png', 1523976270, 'appuser', 'dN-Id8M6wvU:APA91bHB3Xpib5sCVvy-ZLCUpklUamCckx4m1HUmH2fdu7sb4No6Z-umFqo2eaU4bJwLf7TGLSrPz4wB3Q5r5pDw_wldBQLfTlPoL9JoSWmlKLGXGXr2UlxyI2V81jQxIPqDbqrV2hKz', 'Android'),
(3, 'ffgh', 'ggug@guuh.com', 'cUlpbTRGUVRIY3diNzJiNG0rNHZnZz09', 'mobileuser_1524033640.png', 1524033640, 'appuser', 'dN-Id8M6wvU:APA91bHB3Xpib5sCVvy-ZLCUpklUamCckx4m1HUmH2fdu7sb4No6Z-umFqo2eaU4bJwLf7TGLSrPz4wB3Q5r5pDw_wldBQLfTlPoL9JoSWmlKLGXGXr2UlxyI2V81jQxIPqDbqrV2hKz', 'Android');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
